package demo;
import javax.persistence.*;

@Entity
//@DiscriminatorValue("FT")
public class FullTimeEmployee extends Employee{
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "FullTimeEmployee [salary=" + salary + "]";
	}

	private int salary;
	

}
